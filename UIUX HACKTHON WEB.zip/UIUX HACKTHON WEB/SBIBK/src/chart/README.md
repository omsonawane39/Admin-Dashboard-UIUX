# Making Stock Chart's period selector input fields read-only

A Pen created on CodePen.io. Original URL: [https://codepen.io/team/amcharts/pen/WxRWYQ/ab4bcf41ce0ff27e48cc639c87c00180](https://codepen.io/team/amcharts/pen/WxRWYQ/ab4bcf41ce0ff27e48cc639c87c00180).

